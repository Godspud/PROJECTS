#inpu=int(input('inputt number if bits:'))
inpu=3
base_list=['0','1','2','end']

def base(a,base):
    manual_counter=0
    listt_1=base**a
    listt=list('0'*a)
    for counter in range(listt_1):
        print(str(counter)+'=',end='')
        print(listt)
        listt,manual_counter=base_count(listt,manual_counter)
def base_carry(listt,base_no,manual_counter):
    if listt[-1] == base_list[-1]:
        for counter_1 in range(len(listt)-1,-1,-1):
            for counter in range(len(base_list)):
                if listt[counter_1] == base_list[counter]:
                    if manual_counter == len(base_list)-2:
                        manual_counter=-1
                    print(counter_1,'counter_1')
                    listt[counter_1-1]=base_list[manual_counter+1]
                    manual_counter+=1
                return listt,manual_counter
    return listt,manual_counter
def base_count(listt,manual_counter):
    for counter_1 in range(len(base_list)):
        if listt[-1] == base_list[counter_1]:
            listt[-1]=base_list[counter_1+1]
            break
    listt,manual_counter=base_carry(listt,3,manual_counter)
    return listt,manual_counter
base(inpu,3)