word_list=[]
num_list=[]
def learn_object(word_list,num_list,object):
	temp_list=object.split()
	if temp_list[-1] == 'number':
		num_list.append(temp_list[0])
		print('learning number')
		return word_list,num_list
	elif temp_list[-1] == 'word':
		word_list.append(temp_list[0])
		print('learning word')
		return word_list,num_list
def object_search(word_list,num_list,object):
	if object == 'end':
		word_list,num_list=[],[]
		return word_list,num_list
	object=object.split()
	object=object[-1][0:-1]
	for counter in range(len(word_list)):
		if word_list[counter] == object:
			print('word')
			return word_list,num_list
		else:
			print('',end='')
	for counter in range(len(word_list)):
		if object in word_list[counter]:
			print('likely word')
			return word_list,num_list
		else:
			print('',end='')
	for counter in range(len(num_list)):
		if num_list[counter] == object:
			print('number')
			return word_list,num_list
		else:
			print('',end='')
	for counter in range(len(num_list)):
		if object in num_list[counter]:
			print('likely number')
			return word_list,num_list
		else:
			print('',end='')
	for counter in range(len(word_list)):
		if object == word_list[counter]:
			print('word')
			return word_list,num_list
		else:
			print('',end='')
	for counter in range(len(word_list)):
		if word_list[counter] in object:
			print('likely word')
			return word_list,num_list
		else:
			print('',end='')
	for counter in range(len(num_list)):
		if object == num_list[counter]:
			print('number')
			return word_list,num_list
		else:
			print('',end='')
	for counter in range(len(num_list)):
		if num_list[counter] in object:
			print('likely number')
			return word_list,num_list
		else:
			print('',end='')
	print('idk')
	return word_list,num_list
while True:
	object=input('Input: ')
	object_expand=object.split()
	if object_expand[0] == 'mass' and object_expand[1] == 'train':
		inpu=input('type Num to mass train Numbers and type Word to mass train Words')
		if inpu == 'Num':
			while True:
				object=input('Input: ')
				if object == 'end':
					break
		elif inpu == 'Word':
			print('e')
	elif len(object_expand) == 4: 
		word_list,num_list=learn_object(word_list,num_list,object)
	elif len(object_expand) == 3:
		word_list,num_list=object_search(word_list,num_list,object)
	if len(num_list) == 0 and len(word_list) == 0:
		break
