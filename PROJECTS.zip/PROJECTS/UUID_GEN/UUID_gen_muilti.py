import threading
from uuid import uuid4 as UUID4
def gen_UUID(no_of_uuids):
    for counter in range(no_of_uuids):
        UUID=str(UUID4())[19:33]
        if UUID not in UUID_list:
            UUID_list.append(UUID)
        else:
            print('Error invalid UUID',UUID,'Pls try again')
UUID_list=[]
thread1=threading.Thread(target=gen_UUID, args=(1000,))
thread2=threading.Thread(target=gen_UUID, args=(1000,))
thread3=threading.Thread(target=gen_UUID, args=(1000,))
thread1.start()
thread2.start()
thread3.start()
thread1.join()
thread2.join()
thread3.join()

print("Main thread: All tasks completed.",'UUID list',UUID_list)
