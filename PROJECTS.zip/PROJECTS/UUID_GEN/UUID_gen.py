from uuid import uuid4 as UUID4
def gen_UUID(no_of_uuids):
    for counter in range(no_of_uuids):
        UUID=str(UUID4())[19:33]
        if UUID not in UUID_list:
            UUID_list.append(UUID)
        else:
            print('Error invalid UUID',UUID,'Pls try again')
    print(UUID_list)
UUID_list=[]
gen_UUID(1)
