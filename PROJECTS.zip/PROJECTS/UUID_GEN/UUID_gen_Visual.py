import threading
from time import sleep as sleep
from uuid import uuid4 as UUID4
import os
def gen_UUID(no_of_uuids):
    global manual_counter
    for counter in range(no_of_uuids):
        UUID=str(UUID4())[19:33]
        with lock:
            if UUID not in UUID_list:
                UUID_list.append(UUID)
                manual_counter+=1
            else:
                print('Error invalid UUID',UUID,'Pls try again')
def print_progress(total,screen_width):
  while True:
    sleep(0.1)
    with lock:
      progress_base=len(UUID_list)/total
      progress_100=round(progress_base*100,2)
      progress_=progress_base*screen_width
    os.system('clear')
    print(progress_100,'% complete')
    for counter in range(round(progress_)):
      print('#',end='')
    for counter in range(screen_width-round(progress_)):
      print('.',end='')
    print()
    if len(UUID_list) >= total:
      break
manual_counter=0
UUID_list=[]
lock=threading.Lock()
a=int(input('how many UUIDs to be generated'))
b=a
total_things_to_do=a+b
thread1=threading.Thread(target=gen_UUID, args=(a,))
thread2=threading.Thread(target=gen_UUID, args=(b,))
thread3=threading.Thread(target=print_progress, args=(total_things_to_do,129,))
thread1.start()
thread2.start()
thread3.start()
thread1.join()
thread2.join()
thread3.join()
os.system('clear')
print('Main thread: All tasks completed.','UUID_list',UUID_list)
